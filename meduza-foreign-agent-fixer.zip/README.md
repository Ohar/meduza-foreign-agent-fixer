# Прятание плашки инагента на [Медузе](https://meduza.io)

## Что это?

Это плагин для браузера, который просто прячет плашку с сообщением об инагентстве на сайте Медузы.

## Как это выглядит?

![Скриншот с примером](https://raw.githubusercontent.com/Ohar/meduza-foreign-agent-fixer/main/screenshots/screenshot-920x680.png)

## Зачем это?

Чтобы нормально читать Медузу, вне зависимости от того, что по этому поводу думают альтернативно одарённые из МинЮста.

## Как установить?

[comment]: <> (- [Chrome]https://chrome.google.com/webstore/detail/meduza-foreign-agent-fixer/XXX)
- Chrome (будет позже)
- [Firefox](https://addons.mozilla.org/ru/firefox/addon/meduza-foreign-agent-fixer/)
